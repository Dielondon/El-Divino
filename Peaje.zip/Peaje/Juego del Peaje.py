#Juego del Peaje
#Librerias
import tkinter as tk
import numpy as np
import random

#Creación de la Baraja

# Definición de los valores y los palos
valores = ['As', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K']
palos = {
    'Corazones': '♥',
    'Diamantes': '♦',
    'Tréboles': '♣',
    'Picas': '♠'
}

# Creación de la Baraja
baraja = [f"{valor} {simbolo}" for simbolo in palos.values() for valor in valores]

# Valor de las cartas

def valor_carta(carta):
    """
    carta: str. Es la carta a la que se le quiera conocer el valor.

    Esta función genera el valor de una carta teniendo en cuenta lo siguiente. As = 1, J = 11, Q = 12 y K = 13. Para las demás
    cartas el valor que tenga la carta (del 2 al 10) sera el valor que dará está función.

    Return: int. Siendo este el valor de la carta.
    """
    valor_str = carta.split()[0]  # Extrae la parte del valor, ej: "As" de "As ♥"
    
    # Diccionario de valores especiales
    valores = {
        'As': 1,
        'J': 11,
        'Q': 12,
        'K': 13
    }

    # Si está en el diccionario, devolvemos su valor
    if valor_str in valores:
        return valores[valor_str]
    
    # Si no, es un número entre 2 y 10
    return int(valor_str)

#Peaje
# Primer y Segundo Peaje
def Peaje12(Cartamesa,Cartajugador,Voto):
    """
    Cartamesa: str. Es la carta que se encuentra en la mesa en ese momento.
    Cartajugador: str. Es la carta que le sale al jugador totalmente al azar
    Voto: bool. Es el voto que hace el jugador, si el jugador quiere la carta 'Cartajugador' es mayor que 'Cartamesa' entonces el valor
    de 'Voto' es 'True'. Si el jugador cree que es menor entonces 'Voto' = 'False'.

    Los 2 primeros peajes consisten en que hay 2 cartas en la mesa, el jugador en el primer peaje tiene que adivinar que la siguiente 
    carta que sale es mayor o menor que la que está en la mesa. Si adivina pasa al siguiente peaje realizando el mismo proceso.
    De lo contrario, se queda en el primer peaje hasta que adivine. 
    Si el jugador adivina y falla en el segundo peaje, se tendrá que devolver al peaje anterior.

    Return: Tupla. La tupla consistira en la carta 'Cartajugador'; la palabra '¡Pasaste al siguiente peaje!' si adivino o
    '¡Fallaste!' si no adivino (estos se encontraran en una tupla); y un indicador para poder pasar a los 
    siguiente peajes en los cuales '1' significará que paso y '0' que no. ((str,str),int).
    """
    if Voto == True and valor_carta(Cartamesa) >= valor_carta(Cartajugador):
        return ((Cartajugador,'¡Fallaste!'),0)
    elif Voto == False and valor_carta(Cartamesa) <= valor_carta(Cartajugador):
        return ((Cartajugador,'¡Fallaste!'),0)
    if Voto == True and valor_carta(Cartamesa) < valor_carta(Cartajugador):
        return ((Cartajugador,'¡Pasaste al siguiente peaje!'),1)
    elif Voto == False and valor_carta(Cartamesa) > valor_carta(Cartajugador):
        return ((Cartajugador,'¡Pasaste al siguiente peaje!'),1)

# Cuarto Peaje 

def Peaje4(Cartajugador,Voto):
    """
    Cartajugador: str. Es la carta que le sale al jugador totalmente al azar
    Voto: bool. En este caso se decide si es 'par' o 'impar' la carta que le sale al jugador, 'True' para 'par' y 'False' para 'Impar'.

    En este juego el jugador tiene que escoger si la carta que le va a salir es 'par' o 'impar'. Es necesario tener en cuenta que
    las cartas especiales (As, J, Q y K) tiene valores especiales.

    Return: Tupla. La tupla consistira en la carta 'Cartajugador'; la palabra '¡Pasaste al siguiente peaje!' si adivino o
    '¡Fallaste!' si no adivino (estos se encontraran en una tupla); y un indicador para poder pasar a los 
    siguiente peajes en los cuales '1' significará que paso y '0' que no. ((str,str),int).
    """
    if Voto == True and valor_carta(Cartajugador) % 2 == 0:
       return ((Cartajugador,'¡Pasaste al siguiente peaje!'),1) 
    elif Voto == False and valor_carta(Cartajugador) % 2 != 0:
       return ((Cartajugador,'¡Pasaste al siguiente peaje!'),1) 
    else: 
        return ((Cartajugador,'¡Fallaste!'),0)

# Quinto Peaje

def Peaje5(Cartajugador, Voto):
    """
    Cartajugador: str. Es la carta que le sale al jugador totalmente al azar
    Voto: str. En este caso se decide si es un corazón, una pica, un trebol o un diamante.

    En este juego el jugador tiene que escoger si la carta que le va a salir es un corazón, una pica, un trebol o un diamante.

    Return: Tupla. La tupla consistira en la carta 'Cartajugador'; la palabra '¡Pasaste al siguiente peaje!' si adivino o
    '¡Fallaste!' si no adivino (estos se encontraran en una tupla); y un indicador para poder pasar a los 
    siguiente peajes en los cuales '1' significará que paso y '0' que no. ((str,str),int).
    """
    if Voto == Cartajugador[-1]:
        return ((Cartajugador, '¡Pasaste al siguiente peaje!'), 1)
    else:
        return ((Cartajugador, '¡Fallaste!'), 0)


# Interfaz
class JuegoPeajeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Juego del Peaje")
        self.cent = 0
        self.resultado_actual = None
        self.ok_button = None
        self.peaje3_pasado = False

        # Cartas iniciales
        self.cartapeaje1 = random.choice(baraja)
        self.cartapeaje2 = random.choice(baraja)
        self.cartapeaje4 = random.choice(baraja)
        self.cartapeaje5 = random.choice(baraja)

        # Widgets
        self.label_titulo = tk.Label(root, text="Bienvenido al Juego del Peaje", font=("Helvetica", 18))
        self.label_titulo.pack(pady=20)

        self.boton_jugar = tk.Button(root, text="Jugar", command=self.iniciar_juego)
        self.boton_jugar.pack(pady=10)

        self.boton_salir = tk.Button(root, text="Cerrar", command=root.quit)
        self.boton_salir.pack(pady=10)

        self.label_resultado = tk.Label(root, text="", font=("Helvetica", 14))
        self.label_resultado.pack(pady=10)

        self.label_cartas = tk.Label(root, text="", font=("Helvetica", 12))
        self.label_cartas.pack(pady=10)

        self.frame_botones = tk.Frame(root)

    def iniciar_juego(self):
        self.cent = 1
        self.label_titulo.pack_forget()
        self.boton_jugar.pack_forget()
        self.boton_salir.pack_forget()
        self.actualizar_interfaz()

    def actualizar_cartas_peaje(self):
        peajes_texto = f"{self.cartapeaje1} | {self.cartapeaje2} | x | {self.cartapeaje4} | {self.cartapeaje5}"
        self.label_cartas.config(text=f"Cartas del Juego: {peajes_texto}")


    def actualizar_interfaz(self):
        # Limpiar resultados previos
        self.label_resultado.config(text="")
        self.frame_botones.pack_forget()
        self.frame_botones = tk.Frame(self.root)
        self.frame_botones.pack(pady=10)

        # Actualizar el título para el peaje actual
        self.label_titulo.config(text=f"Peaje {self.cent}")
        self.label_titulo.pack()

        # Mostrar las cartas
        self.actualizar_cartas_peaje()

        # Dependiendo del peaje, mostrar botones adecuados
        if self.cent == 1:
            tk.Button(self.frame_botones, text="Alta", command=lambda: self.jugar(True)).pack(side=tk.LEFT, padx=10)
            tk.Button(self.frame_botones, text="Baja", command=lambda: self.jugar(False)).pack(side=tk.LEFT, padx=10)
        elif self.cent == 2:
            tk.Button(self.frame_botones, text="Alta", command=lambda: self.jugar(True)).pack(side=tk.LEFT, padx=10)
            tk.Button(self.frame_botones, text="Baja", command=lambda: self.jugar(False)).pack(side=tk.LEFT, padx=10)
        elif self.cent == 3:
            self.label_resultado.config(text="Peaje 3: Esperando 3 segundos...")
            self.root.after(3000, self.avanzar_de_peaje3)
        elif self.cent == 4:
            tk.Button(self.frame_botones, text="Par", command=lambda: self.jugar(True)).pack(side=tk.LEFT, padx=10)
            tk.Button(self.frame_botones, text="Impar", command=lambda: self.jugar(False)).pack(side=tk.LEFT, padx=10)
        elif self.cent == 5:
            for simbolo in ['♥', '♦', '♣', '♠']:
                tk.Button(self.frame_botones, text=simbolo, command=lambda s=simbolo: self.jugar(s)).pack(side=tk.LEFT, padx=10)
        else:
            self.label_resultado.config(text="¡Ganaste el juego!")

    def jugar(self, voto):
        self.frame_botones.pack_forget()
        cartajugador = random.choice(baraja)

        if self.cent == 1:
            self.resultado_actual = Peaje12(self.cartapeaje1, cartajugador, voto)
            self.cartapeaje1 = cartajugador
        elif self.cent == 2:
            self.resultado_actual = Peaje12(self.cartapeaje2, cartajugador, voto)
            self.cartapeaje2 = cartajugador
        elif self.cent == 4:
            self.resultado_actual = Peaje4(cartajugador, voto)
            self.cartapeaje4 = cartajugador
        elif self.cent == 5:
            self.resultado_actual = Peaje5(cartajugador, voto)
            self.cartapeaje5 = cartajugador

        carta, mensaje = self.resultado_actual[0]
        self.label_resultado.config(text=f"Carta: {carta} - {mensaje}")

        self.ok_button = tk.Button(self.root, text="OK", command=self.continuar_peaje)
        self.ok_button.pack(pady=10)

    def continuar_peaje(self):
        paso = self.resultado_actual[1]
        if self.ok_button:
            self.ok_button.pack_forget()

        if self.cent == 2 and not paso:
            self.cent -= 1
            self.peaje3_pasado = False
        elif self.cent == 4 and not paso:
            self.cent -= 1
            self.peaje3_pasado = False
        elif paso:
            self.cent += 1
            if self.cent == 3:
                self.peaje3_pasado = True
        elif self.cent == 5 and not paso:
            self.cent -= 1
        
        self.actualizar_cartas_peaje()
        self.actualizar_interfaz()

    def avanzar_de_peaje3(self):
        if self.peaje3_pasado:
            self.cent += 1
        else:
            self.cent -= 1
        self.actualizar_cartas_peaje()
        self.actualizar_interfaz()


# Inicio de la app
if __name__ == "__main__":
    root = tk.Tk()
    app = JuegoPeajeApp(root)
    root.mainloop()